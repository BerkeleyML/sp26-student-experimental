OK_FORMAT = True

test = {'name': 'q1b', 'points': 1, 'suites': [{'cases': [{'code': ">>> match = label_distribution_groupby.sort_index().equals(label_distribution.sort_index())\n>>> assert match, 'Label distributions do not match'\n", 'hidden': False, 'locked': False, 'points': 1}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}