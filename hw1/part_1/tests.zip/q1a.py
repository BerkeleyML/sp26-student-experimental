OK_FORMAT = True

test = {'name': 'q1a', 'points': 1, 'suites': [{'cases': [{'code': '>>> assert is_balanced\n', 'hidden': False, 'locked': False, 'points': 1}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}